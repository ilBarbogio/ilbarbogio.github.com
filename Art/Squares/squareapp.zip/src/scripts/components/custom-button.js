export default customElements.define("custom-button",class extends HTMLElement{
	constructor(){
		super()
		const shadowRoot=this.attachShadow({mode:"open"})

		shadowRoot.innerHTML=`
		<style>
			@import "./styles/custom-button.css";
		</style>
		<div id="wrapper">
			Ciao
		</div>
		`
		
		this.width
		this.closedHeight
		this.openFactor
		this.openHeight
	}
	connectedCallback(){
		this.wrapper=this.shadowRoot.querySelector("#wrapper")

		this.width=parseFloat(this.getAttribute("width"))

		this.style.width=`${this.width}px`
		this.style.setProperty("--closed-height",`${this.width}px`)

	}

	listeners(){
		this.wrapper.addEventListener("click",()=>{
			this.box.classList.toggle("open")
		})
	}

	setContent(testo){
		let count=charPerUnitLength*parseFloat(this.width)/(this.closedHeight/4)
		// this.box.innerHTML=testo
		// if(testo.length>count){
		// 	this.box.classList.add("expandable")
		// 	this.dots.style.display="block"
		// 	this.listeners()
		// }
	}
})