export default customElements.define("loading-widget",class extends HTMLElement{
	wrapper
	dots
	animationDelay
	constructor(){
		super()
		const shadowRoot=this.attachShadow({mode:"open"})
		shadowRoot.innerHTML=`
		<style>
			@import "./styles/components/loading-widget.css";
		</style>
		<div class="wrapper">
			<div class="dot"></div>
			<div class="dot"></div>
			<div class="dot"></div>
			<div class="dot"></div>
			<div class="dot"></div>
		</div>
		`
	}
	connectedCallback(){
		this.animationDelay=this.hasAttribute("time")?parseFloat(this.getAttribute("time")):.1
		
		this.wrapper=this.shadowRoot.querySelector(".wrapper")

		this.wrapper.addEventListener("animationend",(ev)=>{
			if(ev.animationName=="slide-in"){
				this.animateDots(true)
				this.dispatch({action:"open"})
			}
		})
		this.wrapper.addEventListener("animationstart",(ev)=>{
			if(ev.animationName=="slide-out"){
				this.animateDots(false)
				this.dispatch({action:"close"})
			}
		})
		
		this.dots=this.wrapper.querySelectorAll("div")
		for(let [i,d] of this.dots.entries()){
			d.style.animationDuration=`${2*this.dots.length*this.animationDelay}s`
			d.style.animationDelay=`${i*this.animationDelay}s`
		}
	}
	animateDots(animate){
		for(let d of this.dots){
			if(animate) d.style.animationName="hop"
			else d.style.animationName="none"
		}
	}
	show(){
		this.wrapper.classList.add("slide-in")
		this.wrapper.classList.remove("slide-out")
	}
	hide(){
		this.wrapper.classList.add("slide-out")
		this.wrapper.classList.remove("slide-in")
	}
	dispatch(detail){
		const event=new CustomEvent("loading-widget",{detail})
		window.dispatchEvent(event)
	}
})