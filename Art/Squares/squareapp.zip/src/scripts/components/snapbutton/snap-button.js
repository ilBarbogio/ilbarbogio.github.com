export default customElements.define("snap-button",class extends HTMLElement{
	wrapper
	backdrop
	button
	constructor(){
		super()
		const shadowRoot=this.attachShadow({mode:"open"})
		shadowRoot.innerHTML=`
		<style>
			@import "./styles/components/snap-button.css";
		</style>
		<button class="wrapper">
			<div class="backdrop"></div>
			<div class="button"></div>
		</button>
		`
	}
	connectedCallback(){
		this.wrapper=this.shadowRoot.querySelector(".wrapper")
		this.wrapper.addEventListener("animationend",(ev)=>{
			if(ev.animationName=="slide-in") this.dispatch({action:"open"})
		})
		this.wrapper.addEventListener("animationstart",(ev)=>{
			if(ev.animationName=="slide-out") this.dispatch({action:"close"})
		})

		this.backdrop=this.wrapper.querySelector(".backdrop")
		this.button=this.wrapper.querySelector(".button")
		
		this.button.addEventListener("click",()=>{
			this.backdrop.classList.add("rotate")
		})
		this.backdrop.addEventListener("animationend",(ev)=>{
			if(ev.animationName=="rotate"){
				this.backdrop.classList.remove("rotate")
				this.hide()
			}
		})
	}

	show(){
		this.wrapper.classList.add("slide-in")
		this.wrapper.classList.remove("slide-out")
	}
	hide(){
		this.wrapper.classList.add("slide-out")
		this.wrapper.classList.remove("slide-in")
	}
	dispatch(detail){
		const event=new CustomEvent("snap-button",{detail})
		console.log(event)
		window.dispatchEvent(event)
	}
})