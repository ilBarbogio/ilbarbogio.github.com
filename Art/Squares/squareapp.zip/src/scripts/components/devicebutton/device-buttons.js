export default customElements.define("device-buttons",class extends HTMLElement{
	wrapper
	buttons
	underText
	constructor(){
		super()
		const shadowRoot=this.attachShadow({mode:"open"})

		shadowRoot.innerHTML=`
		<style>
			@import "./styles/components/device-buttons.css";
		</style>
		<button class="wrapper">
		</button>
		`
	}
	connectedCallback(){
		this.buttons=this.getAttribute("buttons").split(" ")

		this.wrapper=this.shadowRoot.querySelector(".wrapper")
		this.wrapper.addEventListener("animationend",(ev)=>{
			if(ev.animationName=="slide-in") this.dispatch({action:"open"})
		})
		this.wrapper.addEventListener("animationstart",(ev)=>{
			if(ev.animationName=="slide-out") this.dispatch({action:"close"})
		})

		for(let b of this.buttons){
			const button=document.createElement("div")
			button.classList.add("button")
			button.classList.add(b)
			this.wrapper.append(button)

			const text=document.createElement("div")
			text.classList.add("under-text")
			text.innerHTML=b
			button.append(text)
		}
		const spacer=document.createElement("div")
		spacer.classList.add("spacer")
		this.wrapper.append(spacer)
	}

	// rotatedText(container,text,radius,range){
	// 	console.log(radius)
	// 	let chars=text.split("")
	// 	let alpha=range/chars.length
	// 	for(let c of chars){
	// 		let s=document.createElement("span")
	// 		s.style.top=`${radius}px`
	// 		s.innerHTML=c
	// 		container.append(s)
	// 	}
	// }

	show(){
		console.log("show")
		this.wrapper.classList.add("slide-in")
		this.wrapper.classList.remove("slide-out")
	}
	hide(){
		this.wrapper.classList.add("slide-out")
		this.wrapper.classList.remove("slide-in")
	}
	dispatch(detail){
		const event=new CustomEvent("device-buttons",{detail})
		window.dispatchEvent(event)
	}
})