const path = require('path')
const MiniCssExtractPlugin=require("mini-css-extract-plugin")
const HtmlWebpackPlugin=require("html-webpack-plugin")
const CopyWebpackPlugin = require("copy-webpack-plugin")

module.exports = {
  watch:true,
  entry: {
    components:'./src/scripts/components.js',
    index:'./src/index.js',
  },
  plugins:[
    new HtmlWebpackPlugin({
      template:"./src/index.html"
    }),
    new CopyWebpackPlugin({
      patterns:[
        {from:"src/assets/*.svg",to:"assets/[name].svg"},
        {from:"src/scripts/components/*.css",to:"styles/[name].css"},
      ]
    }),
    new MiniCssExtractPlugin()
  ],
  output: {
    filename: '[name].bundle.js',
    path: path.resolve(__dirname, 'dist'),
    clean:true
  },
  module: {
    rules: [
      {
        test: /\.css$/i,
        use: [MiniCssExtractPlugin.loader, 'css-loader'],
      },
      {
        test: /\.s[ac]ss$/i,
        use: [MiniCssExtractPlugin.loader, 'css-loader','sass-loader'],
      },
      {
        test: /\.(png|svg|jpg|jpeg|gif)$/i,
        type: 'asset/resource',
      },
      {
        test: /\.(woff|woff2|eot|ttf|otf)$/i,
        type: 'asset/resource',
      },
    ],
  },
}