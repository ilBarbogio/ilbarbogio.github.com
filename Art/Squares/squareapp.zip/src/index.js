import "./styles.scss"
import { AppState } from "./scripts/state.js"
import { setup as setupInterface } from "./scripts/interface.js"


setupInterface()