export default customElements.define("simple-button",class extends HTMLElement{
	wrapper
	side
	constructor(){
		super()
		const shadowRoot=this.attachShadow({mode:"open"})
		shadowRoot.innerHTML=`
		<style>
			@import "./styles/components/simple-button.css";
		</style>
		<button class="wrapper">
		</button>
		`
	}
	connectedCallback(){
		this.wrapper=this.shadowRoot.querySelector(".wrapper")
		this.side=this.getAttribute("side")
		this.wrapper.classList.add(this.side)

		this.wrapper.addEventListener("animationend",(ev)=>{
			if(ev.animationName=="slide-in") this.dispatch({action:"open",side:this.side})
		})
		this.wrapper.addEventListener("animationstart",(ev)=>{
			if(ev.animationName=="slide-out") this.dispatch({action:"close",side:this.side})
		})

		
		
	}

	show(){
		this.wrapper.classList.add("slide-in")
		this.wrapper.classList.remove("slide-out")
	}
	hide(){
		this.wrapper.classList.add("slide-out")
		this.wrapper.classList.remove("slide-in")
	}
	dispatch(detail){
		const event=new CustomEvent("simple-button",{detail})
		console.log(event)
		window.dispatchEvent(event)
	}
})