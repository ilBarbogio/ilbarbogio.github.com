export class AppState{
	#phase
	constructor(){
		this.#phase="start"
	}

	set phase(newPhase){
		this.#phase=newPhase
	}
	get phase(){return this.#phase}

	

}