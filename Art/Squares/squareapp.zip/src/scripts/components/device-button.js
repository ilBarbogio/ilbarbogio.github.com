export default customElements.define("device-button",class extends HTMLElement{
	constructor(){
		super()
		const shadowRoot=this.attachShadow({mode:"open"})

		shadowRoot.innerHTML=`
		<style>
			@import "./styles/device-button.css";
		</style>
		<button id="wrapper">
		</button>
		`
		
		this.width
		this.closedHeight
		this.openFactor
		this.openHeight
	}
	connectedCallback(){
		this.wrapper=this.shadowRoot.querySelector("#wrapper")
		// this.box=this.shadowRoot.querySelector("#box")
		// this.dots=this.shadowRoot.querySelector("#dots")

		// this.width=parseFloat(this.getAttribute("width"))
		// this.closedHeight=parseFloat(this.getAttribute("closedHeight"))
		// this.openFactor=parseFloat(this.getAttribute("openFactor"))
		// this.openHeight=this.openFactor*this.closedHeight

		// this.style.height=`${this.closedHeight}px`
		// this.style.width=`${this.width}px`
		// this.style.setProperty("--closed-height",`${this.closedHeight}px`)
		// this.style.setProperty("--open-height",`${this.openHeight}px`)
		// this.style.setProperty("--font-size",`${this.closedHeight/4}px`)
		// this.style.setProperty("--line-height",`${this.closedHeight}px`)

	}

	// listeners(){
	// 	this.wrapper.addEventListener("click",()=>{
	// 		this.box.classList.toggle("open")
	// 		// this.dots.classList.toggle("open")
	// 	})
	// }

	// setContent(testo){
	// 	let count=charPerUnitLength*parseFloat(this.width)/(this.closedHeight/4)
	// 	this.box.innerHTML=testo
	// 	if(testo.length>count){
	// 		this.box.classList.add("expandable")
	// 		this.dots.style.display="block"
	// 		this.listeners()
	// 	}
	// }
})